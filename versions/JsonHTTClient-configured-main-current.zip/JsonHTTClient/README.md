# JsonHttpEngineWorkspace — TypeScript HTTP Engine

Implementação incremental do motor HTTP declarativo especificado em Google Drive. O código-fonte do motor é compartilhado entre os clientes e terá distribuição npm/CDN e bundles independentes, conforme a ADR-001. **Não há publicação npm/CDN nem Desktop instalável.** Um VSIX experimental da extensão VS Code pode ser gerado localmente; ainda não foi testado no Extension Host real. O servidor MCP continua experimental.

## Implementado no código

- **T01 (parcial):** tipos TypeScript de RequestFile, Response individual e batch, validação inicial e JSON Schemas Draft 2020-12.
- **T02 (parcial):** arquivos `variables.json` e `*.variables.json`, `enabled`/`protected` por arquivo, herança física, precedência alfabética de múltiplos arquivos ativos, origem de cada variável e Activate/Deactivate.
- **T03 (parcial):** interpolação `{{name}}` em URL, headers, query, autenticação e body; tipos JSON preservados em placeholder completo; resolução recursiva, limites, detecção de ciclo/colisão/chaves inseguras, overrides de foreach; hover/completion/diagnósticos básicos e metadata OAuth sem login.
- **T04 (parcial):** cliente HTTP Node fetch, JSON/text/urlencoded/multipart textual, HTTP 4xx/5xx como Response real, headers de request/response normalizados, mascaramento de headers conhecidos, sessão temporária para revelar originais sem rerun, redirects revalidados e limites de timeout/tamanho.
- **T05 (parcial):** loop sequencial inline ou dataset JSON autorizado, `onError`, AbortSignal/Stop, eventos de progresso, batch `{summary,timings,results[]}`, preflight de variáveis e autorização protected antes do primeiro HTTP.
- **T06 (parcial):** OAuth2/OIDC metadata discovery read-only (well-known OIDC e RFC 8414), metadados validados e limitados em tamanho, definição `OAuthToken` gravada SOMENTE no `variables.json` ou `*.variables.json` escolhido, sem guardar access/refresh tokens. Código + PKCE S256, state e troca de code em endpoint HTTPS usando um CredentialVault fornecido pelo host. A autenticação visual/loopback/vault real e refresh são ainda pendentes.
- **T07 (parcial):** importadores estáticos de cURL e Bash (sem executar shell), OpenAPI 3.x **JSON**, preview sem efeitos e Apply explícito em diretório autorizado sem overwrite; headers de autenticação importados são substituídos por placeholders. OpenAPI YAML, refs remotos e recursos avançados ainda pendentes.
- **F02 (parcial):** CLI agora aceita `oauth discover`, `oauth save`, `import curl|bash|openapi` (preview por padrão e `--apply` explícito) e `variables activate|deactivate`; não realiza login OAuth automaticamente.
- **T09 (parcial):** checagem de esquema/hosts e endereços locais, aprovação explícita de variáveis protegidas, controle básico de destinos HTTP. **Não é SSRF-hardening completo** (DNS pinning, acesso cross-process, races e outras políticas pendentes).
- **F01 (parcial):** CLI inicial `run`, `list`, `variables explain`, suporte a loop/Stop via signal, JSON canônico em stdout e progresso/diagnósticos em stderr. `run-dir` e recursos avançados ainda não estão implementados.
- **T08 (parcial):** entrada browser-safe pura (`packages/sdk-js/src/index.browser.ts`) sem APIs Node; adaptador HTTP browser/CDN bundle/npm publish ainda não feitos.
- **F04/F05 (parciais):** extensão VS Code desktop com Run/Stop em menus nativos, Response JSON em aba untitled editável, integração ao mesmo SDK, hover/completion de placeholders, decorações de método e variáveis no Explorer, schemas de request/variables e toggle dos arquivos ativos. `npm run vscode:pack` produz VSIX experimental sem CLI; sem teste real do Extension Host e tipos oficiais VS Code ainda indisponíveis.
- **T11 (parcial):** TypeScript estrito, ESLint 9 flat config, Prettier, EditorConfig e comandos de qualidade configurados. Ainda é necessário instalar/rodar os plugins ESLint e Prettier reais e gerar lockfile.

## Exemplo de uso da CLI (Node.js 22+)

O código deve ser compilado antes de rodar:

```bash
npm install # requer acesso ao registro npm; gera lockfile
npm run build
node dist/apps/cli/src/main.js --help
```

Um projeto de exemplo:

```text
workspace/
  variables.json
  customers/
    dev.variables.json
    prod.variables.json
    list.request.json
```

`customers/dev.variables.json`:

```json
{
  "enabled": true,
  "protected": false,
  "baseUrl": "https://api.example.com"
}
```

`customers/list.request.json`:

```json
{
  "request": {
    "method": "GET",
    "url": "{{baseUrl}}/customers",
    "headers": [{"name": "Accept", "value": "application/json"}]
  }
}
```

```bash
node dist/apps/cli/src/main.js run ./workspace/customers/list.request.json --root ./workspace
node dist/apps/cli/src/main.js list ./workspace/customers
node dist/apps/cli/src/main.js variables explain ./workspace/customers/list.request.json --root ./workspace --name baseUrl
```

HTTP não criptografado e redes privadas são **bloqueados por padrão**. Para testes explícitos com um servidor local confiável, acrescentar `--allow-http --allow-private-network`. `--allow-protected` autoriza a execução quando variáveis efetivas vierem de arquivos com `protected:true`. `--show-sensitive` é opt-in para exibir headers reais da execução na saída padrão. Não envie outputs desse modo para logs compartilhados.


### OAuth, importação e ativação (funcionalidades parciais F02)

```bash
# Discovery não faz login e não grava arquivos:
node dist/apps/cli/src/main.js oauth discover https://identity.example.com/tenant

# Configuração OAuth em arquivo EXATO escolhido pelo usuário, sem token salvo:
node dist/apps/cli/src/main.js oauth save --issuer https://identity.example.com/tenant \
  --file ./workspace/customers/dev.variables.json --name OAuthToken \
  --client-id your-client-id --scopes customers.read --root ./workspace

# Preview estático: não executa cURL/Bash nem envia request HTTP:
node dist/apps/cli/src/main.js import curl --file ./workspace/request.curl --root ./workspace

# Gerar *.request.json após ação explícita e em pasta autorizada:
node dist/apps/cli/src/main.js import curl --file ./workspace/request.curl \
  --root ./workspace --apply --output-dir ./workspace/customers

# Ativação pelo motor desliga outros arquivos de variáveis da mesma pasta:
node dist/apps/cli/src/main.js variables activate ./workspace/customers/dev.variables.json --root ./workspace
```

`import openapi` suporta JSON 3.x nesta etapa, não YAML. Tokens OAuth são enviados apenas a um `OAuthCredentialVault` que deverá ser implementado pelo host; nenhuma integração automática ao editor, navegador ou CLI existe ainda.

## Qualidade

```bash
npm run format       # Prettier --write (ainda não validado neste ambiente)
npm run check        # Prettier check + ESLint + TypeScript + testes
npm run check:offline # apenas TypeScript + testes, NÃO substitui npm run check
```

No ambiente de desenvolvimento desta entrega, `npm run check:offline` validou TypeScript e **95/95 testes** (contratos, variáveis, HTTP local, loops, OAuth config/discovery/PKCE, importadores, CLI e boundary browser). ESLint/Prettier reais e CI continuam **NOT_RUN/BLOCKED** por falta de dependências acessíveis no registry. Não há lockfile. Nenhuma spec foi marcada `DONE` apenas por esses resultados.

## Limitações e próximas entregas

- **T01:** validador runtime escrito à mão e JSON Schema ainda precisam de teste cruzado de paridade.
- **T02:** ativação multi-arquivo com rollback best-effort, sem transação crash-safe/lock cross-process.
- **T03:** completions estáticas básicas; JSON Schema provider completo de VS Code/Monaco e ligação de credential vault/resolveOAuth assíncrono à execução pertencem à integração posterior.
- **T04/T09:** DNS pinning contra rebinding, política de redirects avançada, binário/stream e artefatos grandes, OAuth/session, redirecionamento de método seguro e APIs de transporte multiplataforma incompletos. Não utilizar esta versão como ferramenta de produção em redes não confiáveis.
- **T05:** foreach sequencial; sem executor paralelo, persisted progress ou recovery.
- **F01/F02:** CLI parcial, sem publicação npm nem `run-dir`. Preview/Apply de importação implementados; OAuth Discovery e salvamento de config presentes, mas `oauth connect` com navegador ainda não implementado.
- **T06:** login no navegador/loopback, refresh token e vault de plataforma ainda não conectados; discovery de rede tem DNS pré-check, mas não DNS pinning. Não usar autenticação externa em ambiente não confiável.
- **T07:** OpenAPI YAML não disponível sem parser robusto; imports só interpretam comandos cURL literais, sem executar scripts.
- **T08:** distribuição npm/CDN, runtime-browser, bundles por cliente e matriz de plataformas ainda não criados.
- **T11/T10:** faltam instalações reais de ESLint e Prettier, lockfile `npm ci`, gates CI de release.
- **F02-F10:** F02, F03, F04 e F05 parciais; servidor MCP/VS Code e integrações Tauri/OAuth/Import visual ainda não concluídos nem validados oficialmente.

Referências: [PLAN e catálogo](https://docs.google.com/document/d/1D2mh30rbWwcS0c-XTFmYsfjQO7cyRxDsnTcTEkFdWMQ/edit), [ADR-001](https://docs.google.com/document/d/1ZOyoBgnItyS_QQGgtaClwJwiPq7czJAmYSEnwpofGDc/edit), [AGENTS](https://docs.google.com/document/d/1EbeQcW6rNCbxq4_UgCiP6E-4UC9607Bz9Q2VfgO-EJA/edit).


## Incremento T06/F03 — OAuth injetado e MCP local

A execução HTTP agora aceita um `OAuthTokenProvider` assíncrono fornecido pelo host. O motor verifica destino/protected antes de consultar credenciais; objetos `OAuthToken` podem estar em qualquer arquivo de variáveis, com precedência D35. A função `connectOAuthSession` prepara PKCE, delega navegador/callback ao host e guarda tokens exclusivamente em vault injetado. Não há login autônomo nem secret store de CLI/desktop ainda. Veja [docs/OAUTH-HOST.md](docs/OAUTH-HOST.md).

Servidor MCP **experimental** em `apps/mcp-server`: `npm run build && node dist/apps/mcp-server/src/main.js --root /pasta`. Também disponível em `node dist/apps/cli/src/main.js mcp serve --root /pasta`. Somente leitura por padrão; flags de permissões são definidas pelo host no startup. Consulte [docs/MCP-SETUP.md](docs/MCP-SETUP.md) antes de ativar execução ou escrita. Ainda não foi validado com SDK MCP oficial/hosts externos.

## Extensão VS Code experimental (F04/F05)

```bash
npm run vscode:pack
# gera artifacts/json-http-client-0.0.1.vsix
```

Instalar pela opção **Install from VSIX** do VS Code desktop. Não precisa instalar CLI ou daemon global. A extensão usa somente workspaces locais confiáveis; os comandos Run/Stop são nativos, cada execução abre Response JSON editável, e as variáveis usam o mesmo resolvedor do motor. HTTP sem TLS e redes privadas são bloqueados por padrão; ajustes explícitos da máquina `jsonHttp.allowHttp` / `jsonHttp.allowPrivateNetworks` existem para uso local confiável.

**Limitações:** o VSIX foi verificado estruturalmente como ZIP, não instalado no VS Code. `vscode-shim.d.ts` é temporário até disponibilidade dos tipos oficiais; Run/Stop foi testado pelo runner independente do VS Code com servidor HTTP local, não por teste de UI real. OAuth interactivo e restauração de sessões além do comportamento nativo do editor não estão completos. Consulte [apps/vscode/README.md](apps/vscode/README.md).

## Incremento: F06 desktop foundation + F01 run-dir + MCP import_apply

`apps/desktop/src` now includes a tested, platform-neutral tab/session model,
Node host bridge using the same SDK execution service as VS Code, and an
atomic app-data session store. Only open tabs are restored, and restoration
**never performs HTTP**. Edited Responses remain editable and Save As writes
user contents unchanged. Tauri + React/Monaco and installers are **not yet
implemented**. See `apps/desktop/README.md`.

The CLI also supports `run-dir` with optional `--recursive` and deterministic
file order. MCP now exposes host-authorized `request_run_dir` and `import_apply`
(requires separate write/apply permissions). See `docs/EXECUTE-DIRECTORY.md`.

This slice is not a release: required ESLint/Prettier, GitHub CI, cross-platform
packaging, DNS pinning, OAuth host login and official MCP interoperability are
still pending. Git `origin` is `https://github.com/lucasnck/JsonHTTClient.git`,
branch `main`; **no push** has been made, per user instruction.

## T08 — Browser runtime ESM (incremento)

`packages/runtime-browser/src/browser-http.ts` introduz `executeBrowserRequest`
com fetch sujeito a CORS, variáveis fornecidas pelo host, preflight `protected`,
HTTP 4xx/5xx real, timeout e limite de resposta. A saída mantém o contrato
`{request,response,timings}`. Não há API Node, filesystem, keychain, OAuth
local ou bypass de CORS. `npm run browser:pack` cria um grafo de módulos ESM
estático em `artifacts/browser-esm`, importável localmente e pronto para ser
hospedado futuramente sob um endereço CDN versionado. **Ainda não foi publicado.**
Documentação: [docs/BROWSER-RUNTIME.md](docs/BROWSER-RUNTIME.md).

## Desktop Tauri 2 — desenvolvimento parcial (F06)

O aplicativo agora possui fontes de **React/Monaco**, um host **Tauri/Rust** e um
**sidecar Node por stdin/stdout** que chama o mesmo SDK do motor. Consulte
[`apps/desktop/README.md`](apps/desktop/README.md) para pré-requisitos, riscos,
comandos e limites. Nenhum daemon global é necessário.

```bash
# Exige Node, Rust/Cargo, toolchains nativas e acesso npm:
npm install
npm --prefix apps/desktop/ui install
npm --prefix apps/desktop install
npm run build
npm run desktop:tauri:dev
```

`npm run desktop:bundle:check` **deve falhar** enquanto não houver UI compilada
e runtime Node da plataforma empacotado; não publicar instalador incompleto.
O frontend nunca carrega Monaco por CDN. A autorização de imports escritos e
variáveis protected permanece desativada no host Tauri até haver confirmação
nativa segura. A resposta pode ter corpo sensível, e Save As atualmente só
aceita caminho sob o workspace.

A suíte TypeScript/Node desta etapa passou **138/138 testes**; o frontend
React/Vite e o binário Rust **não foram compilados**, pois não há dependências
npm nem toolchain Rust disponível neste ambiente (`EAI_AGAIN` no npm). As specs
F06, T08, T10 e F09 permanecem `PENDING` até build/instalação/testes reais.

## Desktop setup e instalador (Windows / macOS / Linux)

A preparação do desktop é automatizada e verifica se cada dependência já existe antes
de instalar. **Instalações de ferramentas do sistema operacional são opt-in.**

```bash
# Para diagnosticar sem instalar:
npm run desktop:doctor

# Na primeira configuração macOS ou Debian/Ubuntu:
bash scripts/bootstrap-desktop.sh --install-system --install-npm

# Após preparar a máquina:
npm run desktop:setup   # npm raiz, Vite/Monaco e CLI Tauri; ignora pacotes já prontos
npm run desktop:dev     # engine TS + Vite + Tauri dev
npm run desktop:build   # engine TS + UI build + Node local embutido + gate + Tauri build

# Apenas simular as etapas:
node tooling/desktop-workflow.mjs build --dry-run
```

No Windows, a preparação inicial usa `scripts/bootstrap-desktop.ps1 -InstallSystem -InstallNpm`
e instala via winget, se ausentes, Node LTS, Rustup, Build Tools C++ e WebView2.
A documentação completa e os requisitos de cada plataforma ficam em
[apps/desktop/README.md](apps/desktop/README.md). O compilador Rust e o SDK
WebKitGTK são pré-requisitos para Linux; não são instalados silenciosamente.
Um instalador Tauri só será produzido quando o runtime Node **da plataforma de
build** estiver empacotado e tiver passado no gate `desktop:bundle:check`.
