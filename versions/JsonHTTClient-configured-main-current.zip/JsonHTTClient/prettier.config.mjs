/** @type {import('prettier').Config} */
export default {
  singleQuote: true,
  semi: true,
  trailingComma: 'all',
  printWidth: 110,
  tabWidth: 2,
  useTabs: false,
  endOfLine: 'lf',
};
