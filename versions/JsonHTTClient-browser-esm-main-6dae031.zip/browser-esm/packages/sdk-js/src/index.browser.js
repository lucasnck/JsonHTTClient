export { validateRequestFile, validateExecutionResult, validateExecutionBatchResult, normalizeRequestHeaders } from '../../core/src/contracts/validation.js';
export { createVariableSnapshot, compareVariableFileNames, isVariablesFileName, validateVariablesFile, planVariableFileActivation } from '../../core/src/variables/variables.js';
export { interpolateRequest, TemplateResolver, TemplateError, PLACEHOLDER } from '../../core/src/templates/interpolation.js';
export { findPlaceholders, hoverVariable, completeAt, diagnosePlaceholders } from '../../language-service/src/language-service.js';
export { checkHttpTarget, HttpPolicyError, approveProtectedExecution, isPrivateHostname } from '../../core/src/security/policies.js';
export { oauthMetadataCandidates, parseOAuthMetadata, normalizeOAuthIssuer, createOAuthDefinition, assertOAuthVariableName, OAuthConfigError } from '../../core/src/oauth/discovery.js';
export { importCurl } from '../../importers/src/curl.js';
export { importOpenApi } from '../../importers/src/openapi.js';
export { ImportError, safeRequestFilename, uniquifyFileNames } from '../../importers/src/import-plan.js';
export { preparePKCEAuthorization, validateOAuthRedirectUri } from '../../core/src/oauth/pkce.js';
export { executeBrowserRequest, BROWSER_CAPABILITIES, BrowserTransportError } from '../../runtime-browser/src/browser-http.js';
//# sourceMappingURL=index.browser.js.map