export class ImportError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.code = code;
        this.name = 'ImportError';
    }
}
const reserved = new Set(['con', 'prn', 'aux', 'nul', ...'com1 com2 com3 com4 com5 com6 com7 com8 com9 lpt1 lpt2 lpt3 lpt4 lpt5 lpt6 lpt7 lpt8 lpt9'.split(' ')]);
export function safeRequestFilename(name) {
    const stem = name.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 95);
    if (!stem || reserved.has(stem) || stem === '.' || stem === '..')
        throw new ImportError('UNSAFE_FILENAME', 'Nome de request inseguro');
    return `${stem}.request.json`;
}
export function uniquifyFileNames(operations) {
    const used = new Set();
    return operations.map(op => {
        const raw = op.filename.replace(/\.request\.json$/i, '');
        let stem = raw, name = op.filename, n = 1;
        while (used.has(name.toLowerCase())) {
            n++;
            stem = raw.slice(0, 85);
            name = safeRequestFilename(`${stem}-${n}`);
        }
        used.add(name.toLowerCase());
        return { ...op, filename: name };
    });
}
//# sourceMappingURL=import-plan.js.map