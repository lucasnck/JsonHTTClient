# JsonHttp browser ESM 0.0.1

Static ESM module graph, browser-safe only. Host this entire folder on an HTTPS CDN with JavaScript MIME types, cache by immutable version, and import `index.mjs`. CORS restrictions remain enforced by the target API. No Node/filesystem/keychain. Not yet publicly deployed.
