import js from '@eslint/js';
import tseslint from 'typescript-eslint';
import prettierConfig from 'eslint-config-prettier';

export default tseslint.config(
  {
    ignores: ['**/dist/**', '**/node_modules/**', '**/coverage/**', '**/*.d.ts'],
  },
  js.configs.recommended,
  ...tseslint.configs.recommendedTypeChecked,
  {
    files: ['**/*.{ts,tsx,mts,cts}'],
    languageOptions: {
      parserOptions: {
        projectService: true,
        tsconfigRootDir: import.meta.dirname,
      },
    },
    rules: {
      '@typescript-eslint/consistent-type-imports': ['error', { prefer: 'type-imports' }],
      '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_', varsIgnorePattern: '^_' }],
    },
  },
  {
    files: ['**/*.{js,mjs,cjs}'],
    extends: [tseslint.configs.disableTypeChecked],
  },
  // Node scripts use Node globals; they are not browser scripts.
  {
    files: ['tooling/**/*.{js,mjs,cjs}'],
    languageOptions: {globals: {process: 'readonly', console: 'readonly'}},
  },
  // The webview has a separate TS configuration in apps/desktop/ui.
  // Root projectService does not know its React/Monaco types.
  {
    files: ['apps/desktop/ui/**/*.{ts,tsx}'],
    extends: [tseslint.configs.disableTypeChecked],
    rules: {'no-empty': ['error', {allowEmptyCatch: true}]},
  },
  // Node's test(...) registration returns a promise that the test runner owns.
  // Synchronous mock implementations are also deliberately typed async.
  // These fixture-only exceptions do NOT relax production TypeScript rules.
  {
    files: ['test/**/*.test.ts'],
    rules: {
      '@typescript-eslint/no-floating-promises': 'off',
      '@typescript-eslint/require-await': 'off',
      '@typescript-eslint/no-explicit-any': 'off',
      '@typescript-eslint/no-unsafe-assignment': 'off',
      '@typescript-eslint/no-unsafe-member-access': 'off',
      '@typescript-eslint/no-unsafe-call': 'off',
      '@typescript-eslint/no-unsafe-argument': 'off',
      '@typescript-eslint/no-unsafe-return': 'off',
      '@typescript-eslint/no-unnecessary-type-assertion': 'off',
      '@typescript-eslint/no-base-to-string': 'off',
      'no-empty': ['error', {allowEmptyCatch: true}],
    },
  },
  prettierConfig,
);
